package com.mmproduction.emsystem;

public class userProfile {
    String userName;
    String contact;
    String userEmail;
    public userProfile(String userName,String userEmail,String contact)
    {
        this.userName = userName;
        this.userEmail = userEmail;
        this.contact = contact;
    }
}
