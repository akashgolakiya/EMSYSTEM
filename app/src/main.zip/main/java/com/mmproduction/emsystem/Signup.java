package com.mmproduction.emsystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.text.Editable;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Signup extends AppCompatActivity {
    EditText name, email, contact, password;
    Button submit;
    FirebaseAuth firebaseAuth;
    private Toolbar mtoolbar;


    //progress dialog
    private ProgressDialog mRegprogress;


    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        name = (EditText)findViewById(R.id.user);
        email = (EditText) findViewById(R.id.email);
        contact = (EditText) findViewById(R.id.contact);
        password = (EditText) findViewById(R.id.password);
        submit = (Button) findViewById(R.id.submitbtn);

        mtoolbar = (Toolbar) findViewById(R.id.Register_toolbar);

        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("Create Account");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRegprogress = new ProgressDialog(this);

        /*addemail();
        addname();
        addpass();
        addphone();*/

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validate_email(email) | !validate_password() | !validate_phone(contact) | !validation_name(name)) {
                    return;
                } else {
                    mRegprogress.setMessage("we register your account");
                    mRegprogress.setCanceledOnTouchOutside(false);
                    mRegprogress.show();

                    firebaseAuth = FirebaseAuth.getInstance();
                    firebaseAuth.createUserWithEmailAndPassword(email.getText().toString(),
                            password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                sendUserData();
                                mRegprogress.dismiss();
                                firebaseAuth.signOut();
                                Toast.makeText(Signup.this, "Successfully Registration", Toast.LENGTH_SHORT).show();
                                finish();
                                startActivity(new Intent(Signup.this, Login.class));
                            } else {
                                mRegprogress.dismiss();
                                Toast.makeText(Signup.this, "Registration Failed!!!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
            }
        });

    }

    public void addphone() {
        contact.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String Contact = contact.getText().toString();
                if (Contact.isEmpty()) {
                    contact.setError("Phone number required");}
                    else if (Contact.length() < 10) {
                        contact.setError("Phone number is not valid");
                    }
                  else {
                    validate_phone(contact);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public boolean validate_phone(View v) {
        String Contact = contact.getText().toString();
        if (Contact.isEmpty()) {
            contact.setError("Phone number required");
            return false;
        } else if (Contact.length() > 10 | Contact.length() < 10) {
            contact.setError("Phone number is not valid");
            return false;
        } else {
            contact.setError(null);
            return true;
        }
    }

    public void addemail() {
        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (email.getText().toString().isEmpty()) {
                    email.setError("Email field Can't be empty ");
                } else if (!email.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")) {
                    email.setError("Email is not valid");
                } else {
                    validate_email(email);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public boolean validate_email(View view) {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        String Email = email.getText().toString();
        if (!Email.matches(emailPattern)) {
            email.setError("Email is not valid");
            return false;
        } else if (Email.isEmpty()) {
            email.setError("Email is required");
            return false;
        } else {
            email.setError(null);
            return true;
        }

    }

    public void addpass() {
        password.addTextChangedListener(new TextWatcher() {
            String pass = password.getText().toString();

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (pass.isEmpty()) {
                    password.setError("Password field can't be Empty");

                } else if (password.getText().toString().length() < 8) {
                    password.setError("Password is too week");

                } else {
                    validate_password();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public boolean validate_password() {
        String pass = password.getText().toString();

        if (pass.isEmpty()) {
            password.setError("Password field can't be Empty");

            return false;
        } else if (password.getText().toString().length() < 8) {
            password.setError("Password is too week");

            return false;
        } else {
            password.setError(null);
            return true;
        }
    }

    public void addname() {
        name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (name.getText().toString().isEmpty()) {
                    name.setError("Last name is required");
                } else {
                    validation_name(name);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public boolean validation_name(View v) {
        if (name.getText().toString().isEmpty()) {
            name.setError("Last name is required");
            return false;
        } else {
            name.setError(null);
            return true;
        }
    }

    private void mailVerified() {
        final FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if (firebaseUser != null) {
            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        sendUserData();
                        Toast.makeText(Signup.this, "Successfully Registration,Please verified your mail", Toast.LENGTH_SHORT).show();
                        firebaseAuth.signOut();
                        finish();
                        startActivity(new Intent(Signup.this, Login.class));
                    } else {
                        Toast.makeText(Signup.this, "Mail isn't sent...", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
            });
        }
    }



    private void sendUserData()
    {
        mRegprogress.dismiss();
        FirebaseUser Current_user = FirebaseAuth.getInstance().getCurrentUser();
        // DatabaseReference myref = firebaseDatabase.getReference(firebaseAuth.getUid());

        String uid = Current_user.getUid();
        //userprofile user = new userprofile(mDisplayname.getText().toString(), mEmail.getText().toString());
        //myref.setValue(user);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("user").child(uid);

        String display_name = email.getText().toString();
        String email = password.getText().toString();
        String contact_no = contact.getText().toString();
        HashMap<String, String> userMap = new HashMap<>();
        userMap.put("name", display_name);
        userMap.put("email", email);
        userMap.put("contact no", contact_no);

        mDatabase.setValue(userMap);
    }
}
