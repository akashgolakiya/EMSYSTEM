package com.mmproduction.emsystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {


    EditText user_email,password;
    Button login;
    TextView sign_up,f_password,mcwlogin;
    private Toolbar mtoolbar;

    FirebaseAuth firebaseAuth;

    ProgressDialog progressDialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        user_email = (EditText)findViewById(R.id.u_name);
        password = (EditText)findViewById(R.id.u_password);
        login = (Button) findViewById(R.id.loginbtn);
        sign_up = (TextView)findViewById(R.id.sign);
        f_password = (TextView)findViewById(R.id.reset);
        mcwlogin = (TextView)findViewById(R.id.continue_without_login);

        mtoolbar = (Toolbar) findViewById(R.id.Register_toolbar);

        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("Login");

        firebaseAuth = FirebaseAuth.getInstance();
        //firebaseAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);
        FirebaseUser user = firebaseAuth.getCurrentUser();

        if(user != null)
        {
            startActivity(new Intent(LoginActivity.this,HomeActivity.class));
            finish();
        }

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = user_email.getText().toString();
                String Password = password.getText().toString();

                progressDialog.setMessage("Wait a Second");
                progressDialog.show();



                if (!validate_email(user_email) | !validate_password(password)) {
                    return;
                }
                else {
                    if(user_email.getText().toString().equals("param@gmail.com") && password.getText().toString().equals("11111111") )
                    {
                        progressDialog.dismiss();
                        Intent i = new Intent(LoginActivity.this,AdminActivity.class);
                        startActivity(i);
                        finish();
                    }
                    else {
                        validate(name, Password);
                    }
                }
            }
        });

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,SignupActivity.class));
                finish();
            }
        });

        f_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,ForgotPasswordActivity.class));
            }
        });

        mcwlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,Home2Activity.class));
                finish();
            }
        });
    }


    private void validate(String email,String Password)
    {
        firebaseAuth.signInWithEmailAndPassword(email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
               if(task.isSuccessful())
               {
                   progressDialog.dismiss();
                   Intent mLginintent = new Intent(LoginActivity.this,HomeActivity.class);
                   startActivity(mLginintent);
                   finish();
               }
               else
               {
                   Toast.makeText(LoginActivity.this,"LoginActivity Failed!!!",Toast.LENGTH_SHORT).show();
                   progressDialog.dismiss();
               }
            }
        });
    }


    public boolean validate_email(View view) {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        String email = user_email.getText().toString();
        if (email.isEmpty()) {
            user_email.setError("Email required");
            return false;
        } else if (!email.matches(emailPattern)) {
            user_email.setError("Email is not valid");
            return false;
        } else {
            user_email.setError(null);
            return true;
        }
    }

    public boolean validate_password(View view) {
        String pass = password.getText().toString();

        if (pass.isEmpty()) {
            password.setError("Password required");
            return false;
        } else if (password.getText().toString().length() < 8) {
            password.setError("Password is too week");
            return false;
        } else {
            password.setError(null);
            return true;
        }
    }




}
