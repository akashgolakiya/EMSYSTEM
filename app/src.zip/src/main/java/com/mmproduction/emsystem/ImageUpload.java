package com.mmproduction.emsystem;

public class ImageUpload {

    private String mImageUri;

    public ImageUpload(){

    }

    public ImageUpload(String mImageUri) {
        this.mImageUri = mImageUri;
    }

    public String getmImageUri() {
        return mImageUri;
    }

    public void setmImageUri(String mImageUri) {
        this.mImageUri = mImageUri;
    }
}
