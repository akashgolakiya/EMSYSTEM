package com.mmproduction.emsystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.ArrayList;

public class ViewallReportActivity extends AppCompatActivity {

    private Toolbar mtoolbar;
    private ListView mlistview;

//    FirebaseDatabase mdatabase;
//    FirebaseListAdapter adapter ;
//    DatabaseReference mdatabasereferense;
    FirebaseListAdapter adapter;
    // /User is a class which i am going to map my data
    ArrayList<String> mlist;
    ArrayAdapter<String> madapter;
    ViewReports malltext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_report);


        mlistview = (ListView) findViewById(R.id.view_all_report_listview);
        mtoolbar = (Toolbar) findViewById(R.id.Register_toolbar);

        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("Activity Reported by User");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Query query = FirebaseDatabase.getInstance().getReference().child("reportmsg");
        FirebaseListOptions<ViewReports> options = new FirebaseListOptions.Builder<ViewReports>().setLayout(R.layout.view_all_report_info_layout).setQuery(query, ViewReports.class).build();

        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(View v, Object model, int position) {

                TextView name = v.findViewById(R.id.idnameinfo);
                //TextView contact_no = v.findViewById(R.id.idcontactinfo);
                TextView email = v.findViewById(R.id.idemailinfo);
                TextView message = v.findViewById(R.id.idtextinfo);
                TextView date = v.findViewById(R.id.iddateinfo);
                TextView time = v.findViewById(R.id.idtimeinfo);
                //ImageView image = v.findViewById(R.id.idimageinfo);

                ViewReports rep = (ViewReports) model;


                date.setText("Date : " + rep.getDate().toString());
                time.setText("Time : " + rep.getTime().toString());
                name.setText("Name : " + rep.getName().toString());
                email.setText("Email : " + rep.getEmail().toString());
                message.setText("Message : " + rep.getMessage().toString());

            }
        };

        mlistview.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();

        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();

        adapter.stopListening();
    }
}
